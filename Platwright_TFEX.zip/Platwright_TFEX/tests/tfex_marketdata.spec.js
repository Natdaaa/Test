import { expect, test } from "@playwright/test";

test.beforeAll(async ({ browser }) => {
  const context = await browser.newContext({
    storageState: "userTFEX.json",
  });
  const page = await context.newPage();
  await page.context().storageState({ path: "userTFEX.json" });
  await page.goto("https://dev2.tfex.co.th/th/home");
});
test("TFEX-MKDT-DMQ-002", async ({ page }) => {
  await page.goto(
    "https://dev2.tfex.co.th/th/market-data/daily-market-quotation/block-trade",
    {
      timeout: 60 * 1000,
      waitUntil: "domcontentloaded",
    }
  );
  const titleCoverpage = "ข้อมูลการซื้อขายแบบรายใหญ่";
  console.log(await page.locator("css=h1.cover-page-title").innerText());
  await expect(page.locator("css=h1.cover-page-title")).toHaveText(
    titleCoverpage
  );
  await page.locator(".group-title").nth(1).click();
  await page.locator(".group-title").nth(1).click();
  await page.pause();
});
test("TFEX-MKDT-MKRP-002", async ({ page }) => {
  await page.goto(
    "https://dev2.tfex.co.th/th/market-data/historical-data/monthly-market-report",
    {
      timeout: 60 * 1000,
      waitUntil: "domcontentloaded",
    }
  );
  const titleCoverpage = "รายงานการซื้อขายรายเดือน";
  console.log(await page.locator("css=h1.cover-page-title").innerText());
  await expect(page.locator("css=h1.cover-page-title")).toHaveText(
    titleCoverpage
  );
  await page.locator(".group-title").nth(1).click();
  await page.locator(".group-title").nth(1).click();
  await page.pause();
});
test("TFEX-MKDT-MKRP-010", async ({ page }) => {
  await page.goto(
    "https://dev2.tfex.co.th/th/market-data/reference-data/metal",
    {
      timeout: 60 * 1000,
      waitUntil: "domcontentloaded",
    }
  );
  const breadcrumb = "Metal";
  console.log(await page.locator("css=li.breadcrumb-item").nth(3).innerText());
  await expect(page.locator("css=li.breadcrumb-item").nth(3)).toHaveText(
    breadcrumb
  );

  await page.pause();
});
