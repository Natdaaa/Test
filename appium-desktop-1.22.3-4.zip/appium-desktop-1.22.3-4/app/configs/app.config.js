import defaultConfig from '../../gui-common/configs/app.config.default';

export default defaultConfig;
